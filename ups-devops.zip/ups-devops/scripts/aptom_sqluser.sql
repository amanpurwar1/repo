-- to be run on master DB
CREATE LOGIN [OMS_Tracking_Login] WITH PASSWORD= '#sj4unq}UdApAD[?'
-- to be run on individual DB
CREATE USER [OMS_Tracking_User] FOR LOGIN [OMS_TRACKING_Login]
GRANT VIEW DATABASE STATE TO OMS_Tracking_User
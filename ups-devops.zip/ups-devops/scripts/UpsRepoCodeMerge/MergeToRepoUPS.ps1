$SOURCE_PATH="C:\Work\Source Code\ups-osp"
$DESTINATION_PATH="C:\TFSSync\ups-osp"

function CopyLibraryProject{

    param(
        $SourceProject,$DesinationProject,$ProjectName
    )

    ROBOCOPY $SOURCE_PATH"$SourceProject" $DESTINATION_PATH"$DesinationProject" `
    /MIR /XD bin obj /XF Dockerfile* Jenkinsfile* NuGet* *.sln *.npmrc /R:2 /W:1 `
    /LOG:"MergeLogs_$ProjectName.log"
    
}

function CopyProject{

    param(
        $SourcePathRelative,$ProjectName
    )

    ROBOCOPY $SOURCE_PATH"$SourcePathRelative" $DESTINATION_PATH"$SourcePathRelative"\k8s `
    /MIR /XD bin obj /XF Dockerfile* Jenkinsfile* NuGet* *.sln *.npmrc /R:2 /W:1 `
    /LOG:"MergeLogs_$ProjectName.log"

}

function CopyWebUIProject{

    param(
        $SourcePathRelative
    )

    ROBOCOPY $SOURCE_PATH"$SourcePathRelative" $DESTINATION_PATH"$SourcePathRelative" `
    /MIR /XD bin obj node_modules /XF Dockerfile* Jenkinsfile* NuGet* *.sln *.npmrc /R:2 /W:1 `
    /LOG:"MergeLogs_WebAppUI.log"


}

function RemoveLibsCsProjs {
    param (
        $ProjectCsproj
    )
    $sharedLibsList = @("Osp.Data","Osp.Core","Osp.Infrastructure")

    $librariesPath = "Libraries\OSPPlatform\Shared Libraries"

    foreach ($lib in $sharedLibsList) {
        dotnet remove $DESTINATION_PATH"\"$ProjectCsproj reference "..\..\..\$librariesPath\$lib\$lib.csproj"        
    }

}

function NugetSharedLibAdd {
    param (
        $Csproj,
        [string[]]$arrayOfProjects
    )
    $fullPath=$DESTINATION_PATH+"\"+$Csproj
   
    [xml]$XmlCsproj = (Get-Content $fullPath)
   
    $ItemgroupNode = $XmlCsproj.CreateElement("ItemGroup")
    $itemsString = ''
    foreach($project in $arrayOfProjects){
        $itemsString+='<PackageReference Include="'+$project+'" Version="1.0.0" Source="hosted" />'
    }
    $ItemgroupNode.InnerXml=$itemsString
    
    $XmlCsproj.DocumentElement.AppendChild($ItemgroupNode)
    $XmlCsproj.Save($fullPath)
    
}

#------- Shared Libraries Project -------
CopyLibraryProject -SourceProject "\Development\ServiceApps\Libraries\OSPPlatform\Shared Libraries" `
-DesinationProject "\Development\ServiceApps\Libraries\OSPPlatform\SharedLibraries" `
-ProjectName "Libraries"

#------- OSP Recruitment Project -------
CopyProject -SourcePathRelative "\Development\ServiceApps\OSP\Osp.Recruitment" `
-ProjectName "RecruitmentProject"

#------- WebApp UI Project -------
CopyWebUIProject -SourcePathRelative "\Development\WebApps\OSP" 

#---Remove Libraries from csproj files -----
RemoveLibsCsProjs -ProjectCsproj "Development\ServiceApps\OSP\Osp.Recruitment\k8s\Osp.Recruitment.Api\Osp.Recruitment.Api.csproj"
RemoveLibsCsProjs -ProjectCsproj "Development\ServiceApps\OSP\Osp.Recruitment\k8s\Osp.Recruitment.Services\Osp.Recruitment.Services.csproj"
RemoveLibsCsProjs -ProjectCsproj "Development\ServiceApps\OSP\Osp.Recruitment\k8s\Osp.Recruitment.DomainEntity\Osp.Recruitment.DomainEntity.csproj"
RemoveLibsCsProjs -ProjectCsproj "Development\ServiceApps\OSP\Osp.Recruitment\k8s\Osp.Recruitment.Test\Osp.Recruitment.Test.csproj"

# ---Add Nuget Package in csproj: To Be Manually Updated---

NugetSharedLibAdd -Csproj "Development\ServiceApps\OSP\Osp.Recruitment\k8s\Osp.Recruitment.Api\Osp.Recruitment.Api.csproj" `
 -arrayOfProjects @("Osp.Core","Osp.Data","Osp.Infrastructure")
 
NugetSharedLibAdd -Csproj "Development\ServiceApps\OSP\Osp.Recruitment\k8s\Osp.Recruitment.DomainEntity\Osp.Recruitment.DomainEntity.csproj" `
-arrayOfProjects @("Osp.Core","Osp.Data","Osp.Infrastructure")

NugetSharedLibAdd -Csproj "Development\ServiceApps\OSP\Osp.Recruitment\k8s\Osp.Recruitment.Services\Osp.Recruitment.Services.csproj" `
-arrayOfProjects @("Osp.Data","Osp.Infrastructure")

NugetSharedLibAdd -Csproj "Development\ServiceApps\OSP\Osp.Recruitment\k8s\Osp.Recruitment.Test\Osp.Recruitment.Test.csproj" `
-arrayOfProjects @("Osp.Data","Osp.Infrastructure")

#---Git Checkin (uncomment for use)---
#cd $DEST_PATH
#git add -A .
#git commit -m 'Merging code from Sapient repository.'
#git push
-- use master DB
CREATE LOGIN gld_login WITH PASSWORD = 'Gu%GC4J5M6W=MbHy'; -- UPS QA Password
create user glduser for login gld_login 


--Use Project DB
create user glduser for login gld_login

ALTER ROLE [db_datareader] ADD MEMBER [glduser];
ALTER ROLE [db_datawriter] ADD MEMBER [glduser];

CREATE ROLE db_executor
GRANT EXECUTE TO db_executor
EXEC sp_addrolemember 'db_executor','glduser'

CREATE ROLE db_viewDefinition
GRANT VIEW DEFINITION TO db_viewDefinition
EXEC sp_addrolemember 'db_viewDefinition','glduser'

-- use master DB
CREATE LOGIN ufh_login WITH PASSWORD = 'RL3k!sXR*PX+RfUb'; -- UPS QA Password
create user ufhuser for login ufh_login 


--Use Project DB
create user ufhuser for login ufh_login

ALTER ROLE [db_datareader] ADD MEMBER [ufhuser];
ALTER ROLE [db_datawriter] ADD MEMBER [ufhuser];

CREATE ROLE db_executor
GRANT EXECUTE TO db_executor
EXEC sp_addrolemember 'db_executor','ufhuser'

CREATE ROLE db_viewDefinition
GRANT VIEW DEFINITION TO db_viewDefinition
EXEC sp_addrolemember 'db_viewDefinition','ufhuser'

-- use master DB
CREATE LOGIN ch_login  WITH PASSWORD = 'mt9Gfx++8w4RLh2J';  --QA Password
create user chuser for login ch_login
 
 
--Use Project DB
create user chuser for login ch_login
 
ALTER ROLE [db_datareader] ADD MEMBER [chuser];
ALTER ROLE [db_datawriter] ADD MEMBER [chuser];
 
CREATE ROLE db_executor
GRANT EXECUTE TO db_executor
EXEC sp_addrolemember 'db_executor','chuser'
 
CREATE ROLE db_viewDefinition
GRANT VIEW DEFINITION TO db_viewDefinition
EXEC sp_addrolemember 'db_viewDefinition','chuser'


ALTER ROLE [db_ddladmin] ADD MEMBER [chuser];
ALTER ROLE [db_owner] ADD MEMBER [chuser];  --(run this in case db_ddladmin does not work)


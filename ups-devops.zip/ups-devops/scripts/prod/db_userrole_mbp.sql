-- use master DB
CREATE LOGIN mbp_login WITH PASSWORD = 'q4R&2LRp7d%#yNPa'; 
create user mbpuser for login mbp_login 
 
 
--Use Project DB
create user mbpuser for login mbp_login
 
ALTER ROLE [db_datareader] ADD MEMBER [mbpuser];
ALTER ROLE [db_datawriter] ADD MEMBER [mbpuser];
 
CREATE ROLE db_executor
GRANT EXECUTE TO db_executor
EXEC sp_addrolemember 'db_executor','mbpuser'
 
CREATE ROLE db_viewDefinition
GRANT VIEW DEFINITION TO db_viewDefinition
EXEC sp_addrolemember 'db_viewDefinition','mbpuser'



ALTER ROLE [db_ddladmin] ADD MEMBER [mbpuser];
ALTER ROLE [db_owner] ADD MEMBER [mbpuser]; --(run this in case db_ddladmin does not work)


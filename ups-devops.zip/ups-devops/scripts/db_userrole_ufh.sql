-- use master DB
CREATE LOGIN ufh_login WITH PASSWORD = 'Qy92h[@6NbYBxz?*';
create user ufhuser for login ufh_login 


--Use Project DB
create user ufhuser for login ufh_login

ALTER ROLE [db_datareader] ADD MEMBER [ufhuser];
ALTER ROLE [db_datawriter] ADD MEMBER [ufhuser];
ALTER ROLE [db_ddladmin] ADD MEMBER [ufhuser];
ALTER ROLE [db_owner] ADD MEMBER [ufhuser];

CREATE ROLE db_executor
GRANT EXECUTE TO db_executor
EXEC sp_addrolemember 'db_executor','ufhuser'

CREATE ROLE db_viewDefinition
GRANT VIEW DEFINITION TO db_viewDefinition
EXEC sp_addrolemember 'db_viewDefinition','ufhuser'







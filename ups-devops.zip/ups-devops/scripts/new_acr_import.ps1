$source="acrscsuateastus2";
#$source="contregoamuat";
##$source="acrospuateastus2";

$destination="acrscsprodeastus2";
#$destination="contregoamprod";
##$destination="acrospprodeastus2";

$sourceimageTag="mffplatformshipment:release-1-0-0-33";
$targetimageTag="mffplatformshipment:2022-02-25";
$username="acrscsuateastus2";        #  copy from Access keys of source registry
$password="MT7760Pzhjq=nImIWEeT+iIgKjPUGtPg";        #  copy from Access keys of source registry

#$username="contregoamuat";
#$password="KfHii2nR2qNY5Ux86wZYwaXYgYQ/rJL0";

###$username="acrospuateastus2";        #  copy from Access keys of source registry
###$password="I0RC8yUAqJ1SbN6k6HU/taX5EQ=L8VMf";        #  copy from Access keys of source registry


az acr login -n $destination --expose-token

az acr import `
   --name $destination `
   --source "$source.azurecr.io/$sourceimageTag" `
   --image "$targetimageTag" `
   --username $username `
   --password $password
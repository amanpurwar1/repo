$source="acrscsuateastus2";
#$source="contregoamuat";
##$source="acrospuateastus2";

$destination="acrscsprodeastus2";
#$destination="contregoamprod";
##$destination="acrospprodeastus2";

$imageTag="mffplatformtrack:v31";
$username="acrscsuateastus2";        #  copy from Access keys of source registry
$password="MT7760Pzhjq=nImIWEeT+iIgKjPUGtPg";        #  copy from Access keys of source registry

#$username="contregoamuat";
#$password="KfHii2nR2qNY5Ux86wZYwaXYgYQ/rJL0";

###$username="acrospuateastus2";        #  copy from Access keys of source registry
###$password="I0RC8yUAqJ1SbN6k6HU/taX5EQ=L8VMf";        #  copy from Access keys of source registry


az acr login -n $destination --expose-token

az acr import `
   --name $destination `
   --source "$source.azurecr.io/$imageTag" `
   --username $username `
   --password $password
#!/bin/bash
##Base Variables
TERRAFORMCONFIGREPO=cmrsautodevconfig
BRANCHNAME=feature/PuppetMaster_Development

## Repository: cmrsautodevconfig
sudo mkdir -p /opt/app/cmrs/automation/$TERRAFORMCONFIGREPO
source cd /opt/app/cmrs/automation/$TERRAFORMCONFIGREPO
sudo git init
sudo git remote add -f origin https://s_dadmin1@del.tools.publicis.sapient.com/bitbucket/scm/cmrsenvautomation/$TERRAFORMCONFIGREPO.git

sudo git config core.sparseCheckout true
sudo echo "terraformconfig" >> .git/info/sparse-checkout
sudo git pull origin $BRANCHNAME
sudo git checkout $BRANCHNAME
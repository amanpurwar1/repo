# ToDo: Enable password less

# Install Terraform and configure for CMRS
cd /tmp
sudo wget https://cmrsdevopscommonstorage.blob.core.windows.net/publicbinaries/Linux/terraform_0.11.3_linux_amd64.zip
sudo unzip -u terraform_0.11.3_linux_amd64.zip
sudo cp terraform /bin

<#
.synopsis
Generate the certificate for environment using Azure Key Vault
.example
./generate-env_certificate.ps1 -SubscriptionId "22860371-xxx" -TenentId "d52c9ea1-xxx" -ApplicationUrl "https://publicisgroupe.xxx" -SecretPassword "p9Z7F0Rxxx" -VaultName "vault-cmrsmar" -CertificateName "cmrsdev151" -ExportPassword "Sapient@123" -SubjectName "CN=marvel.com" -ExportFolder "d:\temp"
#>
param(
    # Azure SubscriptionId
    [Parameter(Mandatory = $true)]
    [string]
    $SubscriptionId,
    # Azure TenentId
    [Parameter(Mandatory = $true)]
    [string]
    $TenentId,
    # Azure ApplicationUrl
    [Parameter(Mandatory = $true)]
    [string]
    $ApplicationUrl,
    # Azure SecretPassword
    [Parameter(Mandatory = $true)]
    [string]
    $SecretPassword,
    # Azure VaultName
    [Parameter(Mandatory = $true)]
    [string]
    $VaultName,
    # Certificate Name
    [Parameter(Mandatory = $true)]
    [string]
    $CertificateName,
    # Certificate Export Password
    [Parameter(Mandatory = $true)]
    [string]
    $ExportPassword,
    # Certificate SubjectName
    [Parameter(Mandatory = $true)]
    [string]
    $SubjectName,
    # Local Folder path where the certificate will be exported to
    [Parameter(Mandatory = $true)]
    [string]
    $ExportFolder
)

Write-Host "Generate Self-Signed certivicate using Azure Key Vault" -BackgroundColor Gray -ForegroundColor Blue
$pfxPath = "$ExportFolder\$CertificateName-export.pfx"

## Login using App Account (use the one that has access to the given vault)
try {
    $sub = Select-AzureRmSubscription -SubscriptionId $SubscriptionId -ErrorAction SilentlyContinue
}
catch {
    $sub = $null
    Write-Host "User needs to login"
}
if (!$sub) {
    $pwd = $SecretPassword | ConvertTo-SecureString -asPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($ApplicationUrl, $pwd)
    Login-AzureRmAccount -Credential $credential -ServicePrincipal -TenantId $TenentId
    Set-AzureRmContext -SubscriptionId $subscriptionId |Out-Null
    $sub = Select-AzureRmSubscription -SubscriptionId $SubscriptionId
}

## Check if pertificate is already present, if not generate one.
$cert = Get-AzureKeyVaultCertificate -VaultName $VaultName -Name $CertificateName -ErrorAction Ignore
$ct = 0
if (!$cert) {
    Write-Host "Certificate not present, need to be created..." -ForegroundColor Yellow

    $policy = New-AzureKeyVaultCertificatePolicy -SubjectName $SubjectName -IssuerName Self -ValidityInMonths $(12 * 5) 
    Add-AzureKeyVaultCertificate -VaultName $VaultName -Name $CertificateName -CertificatePolicy $policy| Out-Null

    Do {
        $cert = Get-AzureKeyVaultCertificate -VaultName $VaultName -Name $CertificateName
        if ($cert.Enabled) {
            $ct = 10
        }
        $ct++
        Start-Sleep -Seconds 5
        Write-Host "Certificate created, giving few seconds to get it initilized, 5 seconds more..." -ForegroundColor Yellow
    }
    Until ($ct -ge 10)
}
else {
    Write-Host "Certificate already present" -ForegroundColor Green
    $ct = 10
}


## Export the certificate
$AzureKeyVaultSecret = Get-AzureKeyVaultSecret -VaultName $VaultName -Name $CertificateName -ErrorAction SilentlyContinue
$PrivateCertKVBytes = [System.Convert]::FromBase64String($AzureKeyVaultSecret.SecretValueText)
$certObject = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -argumentlist $PrivateCertKVBytes, $null, "Exportable, PersistKeySet"
$protectedCertificateBytes = $certObject.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pkcs12, $ExportPassword)

[System.Convert]::ToBase64String($protectedCertificateBytes) |Out-Null
[System.IO.File]::WriteAllBytes($pfxPath, $protectedCertificateBytes)

Write-Host "Certificate Subject: '$($cert.Certificate.Subject)'"
Write-Host "Certificate Expiry: '$($cert.Certificate.NotAfter)'"
Write-Host "Certificate Thumbprint: '$($cert.Thumbprint)'"
Write-Host "Certificate SecretId: '$($cert.SecretId)'"
Write-Host "Exported: '$pfxPath'"

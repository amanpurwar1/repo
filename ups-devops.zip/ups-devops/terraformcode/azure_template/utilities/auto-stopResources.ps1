<#
.synopsis
Start Resources on teh given subscription
.example
./auto-stopResources.ps1 -SubscriptionId "22860371-xxx" -TenentId "d52c9ea1-xxx" -ApplicationUrl "https://publicisgroupe.xxx" -SecretPassword "p9Z7F0Rxxx"
#>
param(
    # Azure SubscriptionId
    [Parameter(Mandatory = $true)]
    [string]
    $SubscriptionId,
    # Azure TenentId
    [Parameter(Mandatory = $true)]
    [string]
    $TenentId,
    # Azure ApplicationUrl
    [Parameter(Mandatory = $true)]
    [string]
    $ApplicationUrl,
    # Azure SecretPassword
    [Parameter(Mandatory = $true)]
    [string]
    $SecretPassword
)
$rg = "cmrssappf151"
$vm = @(
    "cmrspf151cache1"
    "cmrspf151db2"
    "cmrspf151db1"
    "cmrspf151rdp1"
    "cmrspf151rmq2"
    "cmrspf151rmq1"
    "cmrspf151ibmmq1"
)
$vmss = @(
    "NodeHV1"
)

## Login using App Account (use the one that has access to the given vault)
try {
    $sub = Select-AzureRmSubscription -SubscriptionId $SubscriptionId -ErrorAction SilentlyContinue
}
catch {
    $sub = $null
    Write-Host "User needs to login"
}
if (!$sub) {
    $pwd = $SecretPassword | ConvertTo-SecureString -asPlainText -Force
    $credential = New-Object System.Management.Automation.PSCredential($ApplicationUrl, $pwd)
    Login-AzureRmAccount -Credential $credential -ServicePrincipal -TenantId $TenentId
    Set-AzureRmContext -SubscriptionId $subscriptionId |Out-Null
    $sub = Select-AzureRmSubscription -SubscriptionId $SubscriptionId
}

foreach($v in $vm){
    Write-Host "Shutting down VM '$v'..." -ForegroundColor Yellow
    Stop-AzureRmVM -Name $v -ResourceGroupName $rg -Force
    Write-Host "Stopped VM '$v'" -ForegroundColor Green
}

foreach($v in $vmss){
    Write-Host "Shutting down VMSS '$v'..." -ForegroundColor Yellow
    Stop-AzureRmVmss -ResourceGroupName $rg -VMScaleSetName $v -Force
    Write-Host "Stopped VMSS '$v'" -ForegroundColor Green
}
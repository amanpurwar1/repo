<#
.synopsis
Generate Application Terraform files from template
#>

#3 - VM - IP Address allocation
# RDP, RMQ, DB, CACHE

#4 - Add new entry into TF Variable (env_Name, env_Initial)

$templatesource = "D:\git\cmrsautocode\terraformcode\azure_template\app"
$destination = "D:\temp\tf2"
$envName = "dev151"

## No change beyond this

#1 - Copy the files and update
# - Rename the file %app%
# - Find and Replave %app%
$placeholder = "%app%"
$tffiles = Get-ChildItem -Path $templatesource -Filter "*.tf"
foreach ($item in $tffiles) {
    $content = Get-Content -Path $item.FullName
    $content = $content.Replace($placeholder, $envName)
    $newFileName = "$destination\$($item.Name.Replace($placeholder, $envName))"

    $Utf8NoBomEncoding = New-Object System.Text.UTF8Encoding $False
    [System.IO.File]::WriteAllLines($newFileName,$content, $Utf8NoBomEncoding)
    Write-Host " >File: $newFileName" -ForegroundColor Green
}
$commontfFile = "$($destination)\$($envName)_common.tf"


##2 - Update Subnet Address in '<app>_common.tf'
#- Variable: <app>_subnet_addresses

##2 - Update IP-Address allocation in '<app>_vm_<machine>.tf '
#- RDP, RMQ, DB, CACHE
#- Variable: <app>_<machine>_privatestaticip

##3 - Add new entries in 'var_common.tf'
#- Variable: env_Name
#- Cariable: env_Initial

##4 - Update details in service fabric, '<app>_servicefabric.tf'
#- Dependency: Create service account for the given environment e.g. s_cmrsd151app
#- Dependency: Create OU for the given environment e.g. cmrsdev151
#- Dependency: Create a self signed certificate and upload to vault
#- Variable: servicefabric_appusername (Dependency - Create app service account e.g. s_cmrsd151app)
#- Variable: servicefabric_appuserpassword
#- Variable: certificate_thumbprint (Dependency - Create self-signed certificate)
#- Variable: certificate_url (e.g. https://vault-cmrsmar.vault.azure.net/secrets/cmrsdev151/abd7f179bd0642039b04915b5d528eee)
<#
.synopsis
Enable MSMQ service on the given machine.
#>
Add-windowsfeature  MSMQ, MSMQ-Services, MSMQ-Server, MSMQ-Directory, MSMQ-HTTP-Support, MSMQ-Triggers, MSMQ-Multicasting, MSMQ-Routing, MSMQ-DCOM
<#
.synopsis
Copy all custom extension to Storage to be used by CMRS Automation
.description
IMPORTANT: Do not place any copywrite/PIA scripts as these extensions are PUBLICALLY available.
#>

$url = "https://cmrsdevopscommonstorage.blob.core.windows.net/publicbinaries"
$key = "YhLz39nm4/iF7V3b8hq7l+r7YWzdhbsRWHPZncLMZadQZzfun6yRI7z1Z8fsl8bKSmu1KEFnrSJUAfSv5HgdWQ=="

$sourceFolder = "$PSScriptRoot\extensions"

./AzCopy `
    /Source:$sourceFolder `
    /Dest:$url `
    /DestKey:$key `
    /Pattern:"*.*"
<#      
.NOTES  
#===========================================================================  
# Script: installadc_puppet.ps1  
# Created With:ISE 3.0   
# Author: Rethesh Nair   
# Date: 27/11/2017 23:31:21    
# File Name: installadc_puppet.ps1
# Comments:  Install domain Controller from Script  
#===========================================================================  
.DESCRIPTION  
        Basic Domain Controller Script 
        # Server has been named 
        # Server has been Configured with Static IP
     
#>  
 
## Windows PowerShell script for AD DS Deployment 
 
## Basic, Path and Domain variables 

[CmdletBinding()]
param (
      
      [string] $DomainName
    , [string] $DomainUserName
    , [string] $DomainUserPassword
    , [string] $SafePassword
    , [string] $PuppetServer
    , [string] $ClientName
    , [string] $Environment
    
)
$DomainMode = "win2012R2"
$Product   = "winbasesoft"
$Component = "dc"
$PuppetServerFqdn = $PuppetServer + "." + $DomainName
$puppetfactfile  = "C:\ProgramData\PuppetLabs\facter\facts.d\roles.txt"
$puppetconffile = "C:\ProgramData\PuppetLabs\puppet\etc\puppet.conf"
$PuppetClientMsi = "https://cmrsdevopscommonstorage.blob.core.windows.net/publicbinaries/Windows/puppet-agent-1.10.5-x64.msi"
$password = ConvertTo-SecureString -String $SafePassword -AsPlainText -Force
$SecurePassword     = ConvertTo-SecureString -String $DomainUserPassword -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential ($DomainUserName, $SecurePassword)
$PuppetRunInterval="runinterval=525600m"

##Disk initialization

Get-Disk | where partitionstyle -eq 'raw' | Initialize-Disk -PartitionStyle MBR -PassThru | New-Partition -AssignDriveLetter -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel 'NTDS' -Confirm:$false
$drive = Get-Volume | where { $_.FileSystemLabel -eq 'NTDS' }
$NTDSpath = $drive.driveletter + ':\Windows\NTDS'
$SYSVOLpath = $drive.driveletter + ':\Windows\SYSVOL'
New-Item -ItemType directory -Path $NTDSpath
New-Item -ItemType directory -Path $SYSVOLpath

## Adding Roles & Features
 
Import-Module ServerManager
Install-windowsfeature -name AD-Domain-Services �IncludeManagementTools

## Promote to Domain Controller  

Install-ADDSDomainController -Credential $Cred -NoGlobalCatalog:$false -CreateDnsDelegation:$false -CriticalReplicationOnly:$false -DatabasePath $NTDSpath -DomainName $DomainName   -InstallDns:$true -LogPath $NTDSpath  -NoRebootOnCompletion -SysvolPath $SYSVOLpath  -Force:$true -SafeModeAdministratorPassword $password

Start-Sleep -s 120

## Installation of Puppet Agent on DC

Invoke-WebRequest -OutFile C:\puppet.msi $PuppetClientMsi
msiexec /qn /norestart /i C:\puppet.msi PUPPET_MASTER_SERVER=$PuppetServerFqdn  PUPPET_AGENT_ENVIRONMENT=$Environment /passive /l*v C:\Agent_Install.log
Start-Sleep -s 360
if(!(get-content -Path $PuppetConfFile |select-string $PuppetRunInterval -Quiet))
	{
	$PuppetRunInterval | Add-Content -PassThru $PuppetConfFile
	}

if (!(test-path $PuppetFactFile))
{
"component1=$Component" | Add-Content -PassThru $puppetfactfile
"product1=$Product" | Add-Content -PassThru $puppetfactfile
"clientname=$ClientName" | Add-Content -PassThru $puppetfactfile
}
invoke-expression 'cmd /c start powershell -Command { C:\ProgramData\PuppetLabs\Puppet\bin\puppet agent -t }'
Restart-Computer -Force
#!/bin/bash
DomainName=$1
DomainUserName=$2
DomainUserPassword=$3
red="\e[0;31m"
green="\e[0;32m"
blue="\e[0;34m"
#Function to Check The Status Of The Excuted Command
status()
{
if [ $? -ne 0 ];then
COMMENTS=$1
sleep 1
echo -e "$COMMENTS"
sleep 1;
else 
COMMENTS=$2
echo -e "$COMMENTS"
fi
}

dc_oldhostname=`puppet cert list -a | grep .microsoft.com | awk  '{ print $2}' | sed 's|"||g' | xargs`
status  "${red} List of the host with .microsoft failed" "${blue}List of the host with .microsoft sucessful${green}[OK]"

for i in $dc_oldhostname
do
puppet node purge $dc_oldhostname
done
status  "${red}Purge the old host with .microsoft failed" "${blue}Purge the old host with .microsoft sucessfull${green}[OK]"

service pe-puppetserver reload
status  "${red}Reload of puppetserver failed" "${blue}Reload of puppetserver sucessfull${green}[OK]"

yum install sssd realmd oddjob oddjob-mkhomedir adcli samba-common samba-common-tools krb5-workstation openldap-clients policycoreutils-python -y
status  "${red}Installation of RHEL AD packages failed" "${blue}Installation of RHEL AD packages sucessfull${green}[OK]"

sed  -i 's/reddog.microsoft.com//g' /etc/resolv.conf
status  "${red}Resolv.conf update failed" "${blue}Resolv.conf update sucessfull${green}[OK]"

echo $DomainUserPassword | realm join --user=$DomainUserName $DomainName
status  "${red}Adding server to domain failed" "${blue}Adding server to domain sucessfull${green}[OK]"

sed -i 's/use_fully_qualified_names = True/use_fully_qualified_names = False/g' /etc/sssd/sssd.conf
status  "${red}Updaing sssd.conf file failed" "${blue}Updaing sssd.conf file sucessfull${green}[OK]"

systemctl restart sssd
status  "${red}Restarting sssd failed" "${blue}Restarting sssd sucessfull${green}[OK]"

sed -i 's/PasswordAuthentication no/PasswordAuthentication yes/g' /etc/ssh/sshd_config
status  "${red}Updaing sshd_config file failed" "${blue}Updaing sshd_config file sucessfull${green}[OK]"

systemctl restart sshd
status  "${red}Restarting sshd failed" "${blue}Restarting sshd sucessfull${green}[OK]"

echo "%domain\\admins@sapient.net ALL=(ALL)       ALL" >> /etc/sudoers.d/domainusers
status  "${red}Adding domian admin users to sudoers failed" "${blue}Adding domian admin users to sudoers sucessfull${green}[OK]"

echo $DomainUserPassword |passwd $DomainUserName --stdin
status  "${red}Password Reset for Local admin user failed" "${blue}Password Reset for Local admin user sucessfull${green}[OK]"

rm -rf /home/$DomainUserName/.ssh/authorized_keys
status  "${red}Removing ssh authorized key  failed" "${blue}Removing ssh authorized key sucessfull${green}[OK]"

systemctl restart pe-puppetserver
status  "${red}Puppet service restart failed" "Puppet service restart completed${green}[ok]"
<#      
.synopsis
Configure Machine as the Domain Controller.
.description
This should only be used for testing, and not to be used for Production as there is no step to Install Puppet Agent here.
#>  

[CmdletBinding()]
param (
    [string] $DomainName,
    [string] $DomainNetbiosName,
    [string] $SafePassword,
    [string] $ClientName,
    [string] $Environment
)


$DomainMode = "win2012R2"
$password = ConvertTo-SecureString -String $SafePassword -AsPlainText -Force


##Disk initialization
Get-Disk | where partitionstyle -eq 'raw' | Initialize-Disk -PartitionStyle MBR -PassThru | New-Partition -AssignDriveLetter -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel 'NTDS' -Confirm:$false
$drive = Get-Volume | where { $_.FileSystemLabel -eq 'NTDS' }
$NTDSpath = $drive.driveletter + ':\Windows\NTDS'
$SYSVOLpath = $drive.driveletter + ':\Windows\SYSVOL'
New-Item -ItemType directory -Path $NTDSpath
New-Item -ItemType directory -Path $SYSVOLpath

## Adding Roles & Features
Import-Module ServerManager
Install-windowsfeature -name AD-Domain-Services �IncludeManagementTools

## Promote to Domain Controller  
Install-ADDSForest -CreateDnsDelegation:$false -DatabasePath $NTDSpath -DomainName $DomainName -DomainMode $DomainMode  -DomainNetbiosName $DomainNetbiosName -ForestMode $DomainMode -InstallDns:$true -LogPath $NTDSpath -NoRebootOnCompletion -SysvolPath $SYSVOLpath -Force:$true -SafeModeAdministratorPassword $password
Start-Sleep -s 120
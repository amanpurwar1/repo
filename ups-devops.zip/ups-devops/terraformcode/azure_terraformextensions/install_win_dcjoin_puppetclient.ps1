<#
.synopsis
Add windows machine to ad and install puppet agent
.example
.\install_win_dcjoin_puppetclient.ps1 -ComputerName "cmrsudb1" -DomainName "cmrschev.com" -UserName "cmrschvuadmin" -Password "xxx" -PuppetServer "cmrspup1" -ClientName "cmrschev" -Environment "uat1" -Role none
#>
Param(
  [Parameter(Mandatory=$True,Position=1)]
   [string]$ComputerName,
       
   [Parameter(Mandatory=$True)]
   [string]$DomainName,

   [Parameter(Mandatory=$true)]
   [string]$UserName,

   [parameter(mandatory=$true)]
   [string]$Password,

   [parameter(mandatory=$true)]
   [string]$PuppetServer,

   [parameter(mandatory=$true)]
   [string]$ClientName,

   [parameter(mandatory=$true)]
   [string]$Environment,

   [parameter(mandatory=$false)]
   [string]$Role,

   [parameter]
   [String]$Oupath
)


$DomainUser= "$UserName@$DomainName"
$PuppetServerFqdn = $PuppetServer + "." + $DomainName
$PuppetClientMsi = "https://cmrsdevopscommonstorage.blob.core.windows.net/publicbinaries/Windows/puppet-agent-1.10.5-x64.msi"
$PuppetConfFile="C:\ProgramData\PuppetLabs\puppet\etc\puppet.conf"
$PuppetRunInterval="runinterval=525600m"
Invoke-WebRequest -OutFile C:\puppet.msi $PuppetClientMsi



If ($oupath -eq $null)
{
    If(!(get-wmiobject -class win32_computersystem -ComputerName $ComputerName).partofdomain){
    $cred = New-Object System.Management.Automation.PsCredential($DomainUser, (ConvertTo-SecureString $Password -AsPlainText -Force))
    $DCSTATUS = Add-Computer -DomainName $DomainName -Credential $Cred -Passthru -Verbose
    echo "Domain status=$DCSTATUS"
    Start-Sleep -s 120
    }
    Else
    {
    Write-host "computer is already in $DomainName"
    exit
    }
}
Else
{
    If(!(get-wmiobject -class win32_computersystem -ComputerName $ComputerName).partofdomain)
    {
    $cred = New-Object System.Management.Automation.PsCredential($Domainuser, (ConvertTo-SecureString $Password -AsPlainText -Force))
    $DCSTATUS = Add-Computer -DomainName "your.domain.here" -Credential $Cred -OUPath "$Oupath" -Passthru -Verbose 
    echo "Domain status=$DCSTATUS"
    Start-Sleep -s  120	
    }
    Else
    {
    Write-host "computer is already in $DomainName"
    exit
    }

}
echo "DC=$DCSTATUS"

If ( $DCSTATUS.HasSucceeded -eq "True" )
{
	msiexec /qn /norestart /i C:\puppet.msi PUPPET_MASTER_SERVER=$PuppetServerFqdn  PUPPET_AGENT_ENVIRONMENT=$Environment /passive /l*v C:\Agent_Install.log
    Start-Sleep -s  240
	if(!(get-content -Path $PuppetConfFile |select-string $PuppetRunInterval -Quiet))
	{
	$PuppetRunInterval | Add-Content -PassThru $PuppetConfFile
	} 
 }
else
{
	echo "$ComputerName have some issue with $DCSTATUS"
	exit  
}

invoke-expression 'cmd /c start powershell -Command { C:\ProgramData\PuppetLabs\Puppet\bin\puppet agent -t }'
Start-Sleep -s  120
Restart-Computer -Force
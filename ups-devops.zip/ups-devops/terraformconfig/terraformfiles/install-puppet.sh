#!/bin/bash
##Base Variables
PUPPETSERVER=`grep puppet_master_host /var/tmp/pe.conf | awk -F":" '{ print $NF}'  | sed 's/"//g;s/,//g'`
PUPPETMVERSION=2017.2.3
PUPPETMUDOWNLOAD=https://cmrsdevopscommonstorage.blob.core.windows.net/publicbinaries/PuppetMaster/puppet-enterprise-$PUPPETMVERSION-el-7-x86_64.tar.gz
PUPPETCODEREPO=cmrsautocode
PUPPETCONFIGREPO=cmrsautodevconfig
PACKETREPO=cmrsautorelease
red="\e[0;31m"
green="\e[0;32m"
blue="\e[0;34m"
nc='\e[0m'

#Function to Check The Status Of The Excuted Command
status()
{
if [ $? -ne 0 ];then
COMMENTS=$1
sleep 1
echo -e "$COMMENTS"
sleep 1;
else 
COMMENTS=$2
echo -e "$COMMENTS"
fi
}

######################
#Puppet Enterprise   #
######################
sudo yum  install wget ntp git  -y
status "${red}wget,ntp,git package installtion using yum failed" "${blue}wget,ntp,git package installation using yum sucessful${green}[OK]"

sudo hostnamectl set-hostname $PUPPETSERVER
status  "${red}fqdn setup for puppetmaster failed" "${blue}fqdn setup for puppetmaster was sucessfull${green}[OK]"

sudo systemctl restart systemd-hostnamed
status  "${red}systemd-hostnamed service restart failed" "${blue}systemd-hostnamed service restart was sucessfull${green}[OK]"

sudo systemctl restart ntpd
status  "${red}ntpd service restart failed" "${blue}ntpd service restart was sucessfull${green}[OK]"

sudo systemctl enable ntpd
status  "${red}ntpd service enabling failed" "${blue}ntpd service was sucessfully enabled${green}[OK]"

sudo echo  "$(/sbin/ip -o -4 addr list eth0 | awk '{print $4}' | cut -d/ -f1) $PUPPETSERVER" >>  /etc/hosts
status  "${red}Hosts entry insertion failed" "${blue}Hosts entry insertion sucessfull${green}[OK]"

sudo sleep 10

sudo wget -O - https://downloads.puppetlabs.com/puppet-gpg-signing-key.pub | gpg --import
status  "${red}Puppetlabs public sign key download failed" "${blue}Puppetlabs public sign key download sucessfull${green}[OK]"

sudo wget -O /var/tmp/puppet-enterprise-$PUPPETMVERSION-el-7-x86_64.tar.gz $PUPPETMUDOWNLOAD
status  "${red}Puppetlabs enterprise packet download failed" "${blue}Puppetlabs enterprise packet download sucessfull${green}[OK]"

sudo tar -zxvf /var/tmp/puppet-enterprise-$PUPPETMVERSION-el-7-x86_64.tar.gz -C /var/tmp
status  "${red}Puppetlabs enterprise packet untar failed" "${blue}Puppetlabs enterprise packet untar sucessfull${green}[OK]"

sudo /var/tmp/puppet-enterprise-$PUPPETMVERSION-el-7-x86_64/puppet-enterprise-installer -c /var/tmp/pe.conf
status  "${red}Puppetlabs enterprise installer run from pe.conf failed" "${blue}Puppetlabs enterprise installer run from pe.conf sucessfull${green}[OK]"

sudo /opt/puppetlabs/puppet/bin/gem install ncio
status  "${red}ncio gem installation failed" "${blue}ncio gem installation sucessfull${green}[OK]"


sudo echo "*" >> /etc/puppetlabs/puppet/autosign.conf
status  "${red}Auto sign conf update failed" "${blue}Auto sign conf update sucessfull${green}[OK]"

sudo cp /var/tmp/.netrc /root/.netrc
status  "${red}/var/tmp/.netrc copy failed" "${blue}/var/tmp/.netrc copy sucessfull${green}[OK]"
sudo chmod 400 /root/.netrc
#!/bin/bash
red="\e[0;31m"
green="\e[0;32m"
blue="\e[0;34m"
nc='\e[0m'
disk+=(`fdisk -l | grep "Disk /dev" | awk '{ print $2}' | sed 's/://g' | xargs`)
arrayLen=${#disk[@]}
for (( i=0; i<${arrayLen}; i++ ));
do
status=`file -sL ${disk[$i]} | awk '{ print $2 }'`
   if [ $status = "data" ]; then
   pvdisk+=(${disk[$i]})
   pvcreate ${disk[$i]}
   else
   echo "Disk is used"
   fi
done

#Function to Check The Status Of The Excuted Command
status()
{
if [ $? -ne 0 ];then
COMMENTS=$1
sleep 1
echo -e "$COMMENTS"
sleep 1;
else 
COMMENTS=$2
echo -e "$COMMENTS"
fi
}

vgcreate datavg $pvdisk
status "${red}Volume group create failed" "${blue}Volume group create sucessful${green}[OK]"

lvcreate -l 25%FREE -n opt datavg
status "${red}Logical Volume creation for opt is failed" "${blue}Logical Volume creation for opt is sucessful${green}[OK]"

lvcreate -l 33%FREE -n jenkins datavg
status "${red}Logical Volume creation for jenkins is failed" "${blue}Logical Volume creation for jenkins is sucessful${green}[OK]"

lvcreate -l 100%FREE  -n packets datavg
status "${red}Logical Volume creation for packets is failed" "${blue}Logical Volume creation for packets is sucessful${green}[OK]"

mkfs.xfs -f /dev/datavg/opt
status "${red}File system creation for opt is failed" "${blue}File system creation for opt is sucessful${green}[OK]"

mkfs.xfs -f /dev/datavg/jenkins
status "${red}File system creation for jenkins is failed" "${blue}File system creation for jenkins is sucessful${green}[OK]"

mkfs.xfs -f /dev/datavg/packets
status "${red}File system creation for packets is failed" "${blue}File system creation for packets is sucessful${green}[OK]"

mkdir -p /packets
mkdir -p /var/lib/jenkins
echo "/dev/datavg/opt         /opt     xfs    defaults   0   0" >> /etc/fstab
echo "/dev/datavg/jenkins     /var/lib/jenkins xfs    defaults   0   0" >> /etc/fstab
echo "/dev/datavg/packets     /packets xfs    defaults   0   0" >> /etc/fstab
mount -a
status "${red}File systems mount failed" "${blue}File systems mount sucessful${green}[OK]"

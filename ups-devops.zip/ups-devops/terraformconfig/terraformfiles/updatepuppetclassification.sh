#!/bin/bash
## Example params passed ###
#clientname="chevron"
#puppethostname="cmrstmpm1.chevron.net"
#rolesjsonpath="/opt/app/cmrs/automation/cmrsautodevconfig/puppetconfig/hieradata/marvel/puppetroles.json"

### Example script run ###

# chmod +x *.sh; sh updatepuppetclassification.sh chevron cmrstmpm1.chevron.net /opt/app/cmrs/automation/cmrsautodevconfig/puppetconfig/hieradata/marvel/puppetroles.json

########################

###############
yum -y install jq
yum -y install dos2unix
rolesjsonpath=$3
length=$(($(jq ". | length" $rolesjsonpath)-1))
envname=""
for i in $(seq 0 $length); do

  val="$(cat $rolesjsonpath |jq -r ".|keys[$i]")"
  envname="$envname $val"
done

###############

clientname=$1
puppethostname=$2
env=($envname)
echo $puppethostname |cut -d"." -f2-
domainname="$(echo $puppethostname |cut -d"." -f2-)"
/opt/puppetlabs/puppet/bin/ncio backup > ./originalbackup.json
## Merging base json and client name category json file
cat ./puppetclassification/finalbase.json ./puppetclassification/finalclient.json > ./puppetclassification/finalmix2.json

## Updating hostname in json file
sed "s/\[PUPPETHOSTNAME\]/$puppethostname/" ./puppetclassification/finalmix2.json > ./puppetclassification/backup.json

## Iteratively adding environments in json file
for i in ${!env[@]}; do
## Updating json file with client and client id
  sed "s/b8bc3386-1a00-4cd2-b618-f6c425790d82/b8bc3386-1a00-4cd2-b618-f6c425790d8$i/" ./puppetclassification/finalenv.json >> ./puppetclassification/backup.json
## Converting backup file from dos to unix
  dos2unix ./puppetclassification/backup.json
## Updating environment in json file
  sed -i "s/\[ENVIRONMENT\]/${env[$i]}/" ./puppetclassification/backup.json
done

## Updating clientname/domainname in json. Also performing two other operations to format json file
sed -i "s/\[CLIENTNAME\]/$clientname/" ./puppetclassification/backup.json
sed -i "s/\[DOMAINNAME\]/$domainname/" ./puppetclassification/backup.json
sed -i '$s/,//' ./puppetclassification/backup.json
sed -i "\$a ]" ./puppetclassification/backup.json

## Deleting unwanted files
rm -rf ./puppetclassification/finalmix2.json

sudo /opt/puppetlabs/puppet/bin/gem install ncio
## Restoring classification script file
/opt/puppetlabs/puppet/bin/ncio restore < ./puppetclassification/backup.json
